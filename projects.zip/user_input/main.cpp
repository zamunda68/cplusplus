#include <iostream>
#include <cmath>

using namespace std;

int main() {

    int age; //We create a variable to store the user input in
    cout << "Enter your age: "; //Console output
    cin >> age;

    cout << "Your are " << age << " years old";

    return 0;
}

//To get user input for integer or char (number or a single character), you must use "cin >>":
// cin >> age;


//To get user input for string (text), you must use "getline(cin, $thename_of_the_variable);":
//getLine(cin, age, name);
