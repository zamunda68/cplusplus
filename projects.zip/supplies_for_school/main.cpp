#include <iostream>

using namespace std;

int main() {

    //ВХОД:
    //Брой пакети химикали - цяло число в интервала [0...100]
    //Брой пакети маркери - цяло число в интервала [0...100]
    // Литри препарат за почистване на дъска - цяло число в интервала [0…50]
    // Процент намаление - цяло число в интервала [0...100]

    int penPack, markerPack, cleanFluid, discountPercentage;

    cin >> penPack >> markerPack >> cleanFluid >> discountPercentage;

    double penPackPrice = penPack * 5.80;
    double markerPackPrice = markerPack * 7.20;
    double cleanFluidPrice = cleanFluid * 1.20;

    double materialsPrice = penPackPrice + markerPackPrice + cleanFluidPrice;

    double bill = materialsPrice - (materialsPrice * discountPercentage / 100.00);

    cout << bill << endl;

    return 0;
}



//Условие на задачата:

/*Учебната година вече е започнала и отговорничката на 10Б клас - Ани трябва да купи определен брой
пакетчета с химикали, пакетчета с маркери, както и препарат за почистване на дъска. Тя е редовна клиентка
на една книжарница, затова има намаление за нея, което представлява някакъв процент от общата сума.
Напишете програма, която изчислява колко пари ще трябва да събере Ани, за да плати сметката, като
имате предвид следния ценоразпис:
• Пакет химикали - 5.80 лв.
• Пакет маркери - 7.20 лв.
• Препарат - 1.20 лв (за литър)*/