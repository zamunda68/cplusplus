#include <iostream>

using namespace std;

int main() {

    string pass = "s3cr3t!P@ssw0rd";
    cin >> pass;

    if (pass == "s3cr3t!P@ssw0rd"){
        cout << "Welcome";
    } else{

        cout << "Wrong password!";

    }


    return 0;
}

/*Да се напише програма, която чете парола (текст), въведена от потребителя и проверява дали въведената
парола съвпада с фразата "s3cr3t!P@ssw0rd". При съвпадение да се изведе "Welcome". При несъвпадение
да се изведе "Wrong password!";.*/