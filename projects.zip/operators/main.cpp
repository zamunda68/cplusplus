#include <iostream>

using namespace std;

int main() {

   int a = 5, b = 5;
   cout << ( a >= b);

    return 0;
}


//Incrementation operator is "++" and "decremental" operator is "--"

//Relational operators are "<", ">", "<=", ">=", "==", "!="

//Logical operators are "&&", "||", "!".
// "||" means "or", "!" means "not" or negative.