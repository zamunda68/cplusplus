#include <iostream>

using namespace std;

int main() {

    int num;
    cin >> num;

    // If the number can be divided by two (2), it is even.
    if(num % 2 == 0 ){

        cout << "This is even number";

    }else{

        cout << "This is odd number";

    }


    return 0;
}

/*Да се напише програма, която чете цяло число, въведено от потребителя и печата дали е четно или нечетно.
Ако е четно отпечатайте &quot;even&quot;, ако е нечетно &quot;odd&quot;*/