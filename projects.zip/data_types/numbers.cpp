//
// Created by Marin Petkov on 3.11.21.
/*

#include <iostream>
#include <cmath>

using namespace std;

int main()
{

    cout << fmin(4, 3) ;

    return (0);
}
*/