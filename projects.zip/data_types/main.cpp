/*#include <iostream>

using namespace std;

int main()
{

char grade = 'A';
string phrase = "Giraffe Academy";
int age = 50;
double gpa = 2.3;
bool isMale = true;

cout << grade << endl;

    return 0;
}
*/