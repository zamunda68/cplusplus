//Work with strings
// Created by Marin Petkov on 3.11.21.

/*
#include <iostream>

using namespace std;

int main()
{

string phrase = "Giraffe Academy";
string phrasesub = phrase.substr(8, 3);

        cout << phrase.substr(8, 3);



    return 0;
}
*/