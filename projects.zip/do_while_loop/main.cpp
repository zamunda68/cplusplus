#include <iostream>

using namespace std;

int main() {

    //Program for PIN validation with 3 attempts for the user to enter the password;

    //Variables declared:
    int usersPin=1234, pin, errorCounter = 0;

    /*The difference between a "while loop" and "do while loop" is that the "do" part will be executed at least
    once, regardless if the "while" loop is true or false. Usual "while loop" is executed depending on the condition. */

    do
    {

        cout << "Please, enter a pin: ";
        cin >> pin;
        if(pin != usersPin) //if the entered value by the user is not equal to the value of the pin variable
            errorCounter++; // increment the errorCounter value to give the user another pin prompt

    }while(errorCounter < 3 && pin != usersPin); // while there were less than 3 attempts
                                                 // and the entered by the user does not match the pin value

    if( errorCounter < 3)
        cout << "Loading...";

    else
        cout << "Your account is blocked!";


    return 0;
}
