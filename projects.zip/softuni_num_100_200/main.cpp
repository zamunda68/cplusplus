#include <iostream>
#include <cmath>

using namespace std;

int main() {

    int num = 201;

    if(num < 100){

        cout << "Less than 100";
    }
    else if (num >= 100 || num <= 200) {

        cout << "Between 100 and 200";

    }
    else (num > 200);{

        cout << "Greater than 200";
    }

    return 0;
}

/*Да се напише програма, която чете цяло число, въведено от потребителя и проверява дали е под 100, между
100 и 200 или над 200.

 Aко числото е:
- под 100 отпечатайте: "Less than 100"
- между 100 и 200 (включително) отпечатайте: "Between 100 and 200"
- над 200 отпечатайте: "Greater than 200"*/