#include <iostream>

using namespace std;

int main() {

    //сума = депозирана сума + срок на депозита * ((депозирана сума * годишен лихвен процент ) / 12)

    // Депозирана сума – реално число в интервала [100.00 … 10000.00]
    // Срок на депозита (в месеци) – цяло число в интервала [1…12]
    // Годишен лихвен процент – реално число в интервала [0.00 …100.00]

    double depositSum;
    int periodInMonths;
    double percentage;

    cin >> depositSum;             //This could be done this way: cin >> var1 >> var2 >> var3;
    cin >> periodInMonths;
    cin >> percentage;

    double allDepositeMoney = depositSum * (percentage / 100.0);
    double moneyForMonth = allDepositeMoney / 12;
    double result = depositSum + periodInMonths * (moneyForMonth);

    cout << result << endl;

    return 0;
}
