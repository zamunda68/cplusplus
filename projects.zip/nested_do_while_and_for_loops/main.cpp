#include <iostream>

using namespace std;

int main() {

    //Defined variables//
    int grade, sum = 0;

    //for loop (initialization; condition; increment)//
    for (int i = 0; i < 3; i++) {

        //nested do while loop - in nested loop of this type, the condition in the while loop is executed first//
        do {
            cout << "Enter grade " << i + 1 << ": ";
            cin >> grade;

        //while loop which is executed first//
        } while (grade < 1 || grade > 5); {
                sum += grade;
            }
        }
        cout << "Sum = " << sum << endl;
        cout << "Avg grade is " << (float)sum / 3.0 << endl;
        return 0;
    }

    /*Basic syntax of a nested do while loop:
     *
     *
    do {
    while(condition) {
    for (initialization; condition; increment) {
    //set of statement of inside do-while loop
    }
    // set of statement of inside do-while loop
    }
    //set of statement of outer do-while loop
    } while(condition);
    *
    */