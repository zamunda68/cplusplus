#include <iostream>

void function(){

    std::cout << "Hello from function()\n";
}

int main() {

    std::cout << "Hello from main()!" << std::endl;
    function();

    return 0;
}
