#include <iostream>

using namespace std;

int main()
{

    int luckyNum[] = {4, 16, 21, 34, 47};

    cout << luckyNum[4] << endl;

    return 0;
}
