#include <iostream>
#include <cmath>

using namespace std;

int main() {

    double rad;
    cout << "Please, enter radians value: ";
    cin >> rad;

    double deg = rad * 180 / 3.14;

    double result = round(deg);

    cout << result << endl;

    return 0;
}
