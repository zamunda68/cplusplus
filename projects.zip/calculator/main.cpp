#include <iostream>

using namespace std;

int main() {

    string name = "John";
    int age;

        cout << "Hello " << name << " please, enter your " << age << " here:";
        cin >> age;

    return 0;
}
