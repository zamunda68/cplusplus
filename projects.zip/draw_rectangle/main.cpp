#include <iostream>
#include <iomanip>

/* iomanip is a library that is used to manipulate the output of C++ program.
   Using C++, header providing parametric manipulators */

using namespace std;

int main() {

    //Draw rectangle with nested for loop

    int height, width;

    cout << "Enter height: ";
    cin >> height;
    cout << "Enter width: ";
    cin >> width;
    char symbol;
    cout << "Symbol: ";
    cin >> symbol;

    for(int h = 0; h < height; h++ ){
        for(int w = 0; w < width; w++){
            cout << setw(3) << symbol; // setw() is function from the iomanip library
        }
        cout << endl;
    }

    return 0;
}
