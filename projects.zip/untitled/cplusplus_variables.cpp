//
// Created by Marin Petkov on 2.11.21.
// Simple variables learning

#include <iostream>

using namespace std;

int main()

{

    string characterName = "George";
    int characterAge;
    characterAge = 35;

    cout << "-------------------------------------" << endl;
    cout << "There was once a man named " << characterName << endl;

    characterAge = 50;

    cout << "He was " << characterAge <<  " years old" << endl;
    cout << "He liked the name John" << endl;
    cout << "But he did not like being " << characterAge << endl;
    cout << "-------------------------------------" << endl;
    return 0;

}

// In C++ variables data types must be specified.
// Also, in C++ variables values can be changed on the run - in the middle in nowhere, without any issues.
// In order to include a variable in string, the variable should be added between two pairs of "<<"
