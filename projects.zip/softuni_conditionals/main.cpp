#include <iostream>

using namespace std;

/*Напише конзолна програма, която чете оценка (реално число), въведена от потребителя и отпечатва
"Excellent!" ако оценката е 5.50 или по-висока.*/

int main() {

    double grade;
    cin >> grade;

    if(grade >= 5.50) {

        cout << "Excellent!";

    } else {

        cout << "Not excellent, sorry.";
    }
    return 0;
    }

