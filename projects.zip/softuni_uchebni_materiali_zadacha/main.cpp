#include <iostream>

using namespace std;

int main() {

    //Вход:
    // Брой страници в текущата книга – цяло число в интервала [1…1000]
    // Страници, които прочита за 1 час – цяло число в интервала [1…1000]
    // Броят на дните, за които трябва да прочете книгата – цяло число в интервала [1…1000]

    int bookPages, pagesRedForHour, daysNeeded;

    cin >> bookPages >> pagesRedForHour >> daysNeeded;

    int hoursNeededForBook = bookPages / pagesRedForHour;
    int hoursEveryDay = hoursNeededForBook / daysNeeded;

    cout << hoursEveryDay << endl;

    return 0;
}





//УСЛОВИЕ НА ЗАДАЧАТА:

/*За лятната ваканция в списъка със задължителна литература на Жоро има определен брой книги. Понеже
Жоро предпочита да играе с приятели навън, вашата задача е да му помогнете да изчисли колко часа на ден
трябва да отделя, за да прочете необходимата литература*/