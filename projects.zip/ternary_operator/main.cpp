#include <iostream>

using namespace std;

int main() {

    //Guessing game

    int hostUserNum, guestUserNum;

    cout << "Host: ";
    cin >> hostUserNum;
    system("clear");
    cout << "Guest: ";
    cin >> guestUserNum;

    //Ternary a.k.a. conditional operator, which is shorter version of if/else statement;

    (hostUserNum==guestUserNum)? cout << "Correct!" : cout << "Failed";

    /*Below is a simple if/else statement
    /(hostUserNum==guestUserNum)
        cout << "Correct!";

        else
            cout << "Failed";
    /end of the statement*/

    return 0;
}
