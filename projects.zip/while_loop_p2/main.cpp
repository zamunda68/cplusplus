#include <iostream>

using namespace std;

int main() {

    //Count digits of a number entered by a user in the console;
    int number;
    cout << "Number: ";
    cin >> number;

    if (number == 0)
        cout << "You have entered zero! Please do not enter 0.\n";
    else{

        //Check if the number is negative, in case the user enters negative number:

        if(number < 0)

            //Convert negative number to positive by multiplying it to -1
            number = -1 * number;

        int counter = 0;
        while(number > 0 ){
            number = number / 10;
            //num =/ 10;
            counter++;
        }
    cout << "Number contains " << counter << " digits";

    }


    return 0;
}
