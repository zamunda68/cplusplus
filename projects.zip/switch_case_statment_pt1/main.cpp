#include <iostream>

using namespace std;

int main() {

    float num1, num2;
    char operation;
    cout << "***Marin's Calculator***" << endl;
    cin >> num1 >> operation >> num2; //user enters numbers and operation (-,+,/,* and so on)

    //Switch case statement exists to allow multiple conditions to be handled
    switch (operation) {

        case '-': cout << num1 << operation << num2 <<"="<<num1 - num2; break;
        case '+': cout << num1 << operation << num2 <<"="<<num1 + num2; break;
        case '/': cout << num1 << operation << num2 <<"="<<num1 / num2; break;
        case '*': cout << num1 << operation << num2 <<"="<<num1 * num2; break;
        case '%':
            bool isNum1Int, isNum2Int;
            (int) num1 == num2;

            //If the number is 5.0, the (int) will remove the .0, and it will leave a whole number.
            // this is also called data type conversation - changing the data type from one to another//
            
            isNum1Int = ((int)num1 == num1);//example: 5==5.0
            isNum2Int = ((int)num2 == num2);//example: 6==6.1

            if(isNum1Int && isNum2Int)
                cout << num1 << operation << num2 <<"="<< (int)num1 % (int)num2;
            else
                cout << "Not valid!";

                break;
        default: cout << "This operation is not valid!";
    }

    return 0;
}
