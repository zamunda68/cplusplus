#include <iostream>

using namespace std;

// The variable "name" in the function is called parameter
void introduceMe(string name, string city, int age){

    cout << "My name is " << name << endl;
    cout << "I am from " << city << endl;
    cout << "I am " << age << " years old" << endl;
}

int main() {

    // The string "Marin" in this case, when we call the function is called argument

    //introduceMe("Marin", "Plovdiv", 29); < here the values are hard-coded;
    //introduceMe("Kristina", "Plovdiv", 27); < here the values are hard-coded;

    //Below we allow the user to add values, not hard-code them as don above.

    string name, city;
    int age;
    cout << "Name: ";
    cin >> name;
    cout << "City: ";
    cin >> city;
    cout << "Age: ";
    cin >> age;

    introduceMe(name, city, age);

    return 0;
}

// The return function type "void" means the function will return nothing;